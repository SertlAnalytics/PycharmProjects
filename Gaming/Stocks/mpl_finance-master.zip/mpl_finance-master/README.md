[![Build Status](https://travis-ci.org/matplotlib/mpl_finance.svg?branch=master)](https://travis-ci.org/matplotlib/mpl_finance)

This module consists of code extracted from the deprecated matplotlib.finance
module along with a few examples of usage.

The code is provided as is and is basically un-maintained.

If you are interested in maintaining the code please get in touch
via matplotlib-devel@python.org
